module.exports = {
  semi: false,
  trailingComma: true,
  singleQuote: true,
  printWidth: 100,
  tabWidth: 2
};