export const logoNegative = [
  '608 134',
  `

  <svg xmlns="http://www.w3.org/2000/svg" width="350.041" height="135.999" viewBox="0 0 82.041 15.999">
  <g id="etrace_logo" transform="translate(0 0)">
    <path id="Path_5020" data-name="Path 5020" d="M2981.867,1868.676v-1.695h11.957v1.695h-5.1v14.273h-1.769v-14.273Z" transform="translate(-2968.702 -1866.981)" fill="#fff"/>
    <path id="Path_5021" data-name="Path 5021" d="M3087.593,1882.949v-15.968h7.206a6.242,6.242,0,0,1,3.7.8,3.438,3.438,0,0,1,1.014,2.847v2.413a3.33,3.33,0,0,1-.51,1.968,2.294,2.294,0,0,1-1.55.9,2.477,2.477,0,0,1,1.6.976,4.181,4.181,0,0,1,.462,2.23v3.839h-1.844v-3.292a3.607,3.607,0,0,0-.542-2.322,2.817,2.817,0,0,0-2.118-.606h-5.662v6.22Zm6.852-14.273h-5.094v6.391h5.094a4.6,4.6,0,0,0,2.612-.493,2.158,2.158,0,0,0,.616-1.769v-1.866a2.194,2.194,0,0,0-.6-1.78A4.675,4.675,0,0,0,3094.445,1868.676Z" transform="translate(-3060.786 -1866.981)" fill="#fff"/>
    <path id="Path_5022" data-name="Path 5022" d="M3193.567,1882.949l5.9-15.968h2.906l5.93,15.968h-1.823l-1.523-4.086h-8.075l-1.49,4.086Zm3.9-5.662h6.917l-3.185-8.611h-.569Z" transform="translate(-3153.088 -1866.981)" fill="#fff"/>
    <path id="Path_5023" data-name="Path 5023" d="M3316.633,1872.325q0-2.995,1.146-4.167t4.047-1.172h1.822q2.88,0,4.042,1.01a4.347,4.347,0,0,1,1.162,3.429v.681h-1.78v-.429a3.185,3.185,0,0,0-.722-2.418,4.4,4.4,0,0,0-2.826-.649h-1.2a8.74,8.74,0,0,0-2.057.173,2.439,2.439,0,0,0-1.073.581,2.138,2.138,0,0,0-.6,1.041,10.6,10.6,0,0,0-.173,2.35v4.44a10.526,10.526,0,0,0,.173,2.34,2.14,2.14,0,0,0,.6,1.042,2.444,2.444,0,0,0,1.042.581,8.692,8.692,0,0,0,2.088.173h1.2a4.3,4.3,0,0,0,2.869-.681,3.608,3.608,0,0,0,.711-2.607c0-.2,0-.346-.005-.45s-.008-.2-.015-.293h1.769v1.026q0,2.6-1.125,3.612t-4.078,1.016h-1.822q-2.9,0-4.047-1.173t-1.146-4.167Z" transform="translate(-3260.276 -1866.985)" fill="#fff"/>
    <rect id="Rectangle_41" data-name="Rectangle 41" width="11.208" height="1.705" transform="translate(0 0.005)" fill="#e50019"/>
    <rect id="Rectangle_42" data-name="Rectangle 42" width="11.208" height="1.705" transform="translate(0 14.295)" fill="#2a559c"/>
    <rect id="Rectangle_43" data-name="Rectangle 43" width="11.208" height="1.705" transform="translate(0 7.132)" fill="#00973d"/>
    <rect id="Rectangle_44" data-name="Rectangle 44" width="11.208" height="1.705" transform="translate(70.833 0.005)" fill="#e50019"/>
    <rect id="Rectangle_45" data-name="Rectangle 45" width="11.208" height="1.705" transform="translate(70.833 14.295)" fill="#2a559c"/>
    <rect id="Rectangle_46" data-name="Rectangle 46" width="11.208" height="1.705" transform="translate(70.833 7.132)" fill="#00973d"/>
  </g>
</svg>
`,
]
